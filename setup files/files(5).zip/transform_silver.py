"""
Bronze -> Silver transformations.

Each function is idempotent: it deletes and rebuilds the silver rows derived
from a given bronze source, so re-running after new bronze data arrives is
always safe (no duplicate rows, no manual cleanup).
"""
from __future__ import annotations

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from models import GameLine, GameResult, League, Matchup, Member, OwnedTeam, Outcome, Schedule
from silver_models import SilverGameFact, SilverMatchupFact, SilverScheduleResolved


def _period_from_date(game_date) -> str:
    return game_date.strftime("%Y-%m")


def build_silver_game_facts(session: Session) -> int:
    """
    Rebuild silver_game_facts from every GameResult, joined to its OwnedTeam,
    Member, League, and (if present) matching GameLine. Re-derives outcome
    from the raw score as a data-quality check against what bronze stored.
    """
    session.execute(delete(SilverGameFact))

    results = session.execute(
        select(GameResult, OwnedTeam, Member, League)
        .join(OwnedTeam, GameResult.owned_team_id == OwnedTeam.id)
        .join(Member, OwnedTeam.member_id == Member.id)
        .join(League, OwnedTeam.league_id == League.id)
    ).all()

    rows_built = 0
    for result, owned_team, member, league in results:
        line = session.execute(
            select(GameLine).where(
                GameLine.owned_team_id == result.owned_team_id,
                GameLine.odds_api_event_id == result.odds_api_event_id,
            )
        ).scalar_one_or_none()

        # Data-quality check: recompute win/loss/tie from the raw score and
        # compare to what bronze recorded. Doesn't re-check cover (needs the
        # spread's exact push/cover math), just catches an outright W/L/T mismatch.
        if result.team_score > result.opponent_score:
            expected_basic = "win"
        elif result.team_score < result.opponent_score:
            expected_basic = "loss"
        else:
            expected_basic = "tie"
        stored_basic = "loss" if result.outcome == Outcome.LOSS else (
            "tie" if result.outcome == Outcome.TIE else "win"
        )
        is_valid = expected_basic == stored_basic

        session.add(
            SilverGameFact(
                source_result_id=result.id,
                source_line_id=line.id if line else None,
                owned_team_id=owned_team.id,
                member_id=member.id,
                member_name=member.name,
                league_id=league.id,
                league_name=league.name,
                team_name=owned_team.team_name,
                opponent_name=result.opponent_name,
                game_date=result.game_date,
                period=_period_from_date(result.game_date),
                spread_for_team=line.spread_for_team if line else None,
                team_score=result.team_score,
                opponent_score=result.opponent_score,
                outcome=result.outcome,
                points=result.points,
                is_valid=is_valid,
            )
        )
        rows_built += 1

    session.commit()
    return rows_built


def build_silver_matchup_facts(session: Session) -> int:
    """Rebuild silver_matchup_facts from every finalized Matchup."""
    session.execute(delete(SilverMatchupFact))

    matchups = session.execute(
        select(Matchup, Schedule).join(Schedule, Matchup.schedule_id == Schedule.id).where(
            Matchup.is_final.is_(True)
        )
    ).all()

    member_names: dict[int, str] = {
        m.id: m.name for m in session.execute(select(Member)).scalars().all()
    }

    rows_built = 0
    for matchup, schedule in matchups:
        if schedule.member_b_id is None:
            continue  # bye round -- no opposing side to build a matchup fact for

        winner_name = member_names.get(matchup.winner_id) if matchup.winner_id else None
        session.add(
            SilverMatchupFact(
                source_matchup_id=matchup.id,
                schedule_id=schedule.id,
                period=schedule.period,
                round_number=schedule.round_number,
                is_playoff=schedule.is_playoff,
                round_name=schedule.round_name,
                member_a_id=schedule.member_a_id,
                member_a_name=member_names.get(schedule.member_a_id, "Unknown"),
                member_a_points=matchup.member_a_points,
                member_b_id=schedule.member_b_id,
                member_b_name=member_names.get(schedule.member_b_id, "Unknown"),
                member_b_points=matchup.member_b_points,
                winner_id=matchup.winner_id,
                winner_name=winner_name,
                margin=abs(matchup.member_a_points - matchup.member_b_points),
            )
        )
        rows_built += 1

    session.commit()
    return rows_built


def build_silver_schedule_resolved(session: Session) -> int:
    """Rebuild silver_schedule_resolved from Schedule rows that have both members set."""
    session.execute(delete(SilverScheduleResolved))

    resolved = session.execute(
        select(Schedule).where(Schedule.member_a_id.is_not(None), Schedule.member_b_id.is_not(None))
    ).scalars().all()

    rows_built = 0
    for row in resolved:
        session.add(
            SilverScheduleResolved(
                source_schedule_id=row.id,
                period=row.period,
                round_number=row.round_number,
                member_a_id=row.member_a_id,
                member_b_id=row.member_b_id,
                is_playoff=row.is_playoff,
                round_name=row.round_name,
            )
        )
        rows_built += 1

    session.commit()
    return rows_built


def build_all_silver(session: Session) -> dict[str, int]:
    """Run all bronze -> silver builds in dependency order and return row counts."""
    return {
        "silver_game_facts": build_silver_game_facts(session),
        "silver_matchup_facts": build_silver_matchup_facts(session),
        "silver_schedule_resolved": build_silver_schedule_resolved(session),
    }
