"""
Database models for the fantasy sports tracker.

Season shape (see project scope doc for full rationale):
- 8 members, each owning one team per league across 7 leagues (56 OwnedTeams).
- 10 monthly rounds: 7 round-robin + 1 bye + 2 playoff rounds (semifinal, final).
- Season runs March -> December.
- Scoring per game: loss=-1, tie=0, push=+1, win=+1, win+cover=+2.
"""
from __future__ import annotations

import enum
from datetime import datetime

from sqlalchemy import (
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class Outcome(str, enum.Enum):
    LOSS = "loss"
    TIE = "tie"
    PUSH = "push"
    WIN = "win"
    WIN_COVER = "win_cover"


# Single source of truth for scoring -- used when a GameResult is ingested.
POINTS_BY_OUTCOME: dict[Outcome, int] = {
    Outcome.LOSS: -1,
    Outcome.TIE: 0,
    Outcome.PUSH: 1,
    Outcome.WIN: 1,
    Outcome.WIN_COVER: 2,
}


class Member(Base):
    __tablename__ = "members"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)

    owned_teams: Mapped[list["OwnedTeam"]] = relationship(
        back_populates="member", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Member id={self.id} name={self.name!r}>"


class League(Base):
    __tablename__ = "leagues"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    # e.g. "americanfootball_nfl", "basketball_nba" -- The Odds API sport key
    odds_api_sport_key: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)

    owned_teams: Mapped[list["OwnedTeam"]] = relationship(back_populates="league")

    def __repr__(self) -> str:
        return f"<League id={self.id} name={self.name!r}>"


class OwnedTeam(Base):
    """One (member, league) pair -- 56 rows once the draft is fully seeded."""

    __tablename__ = "owned_teams"
    __table_args__ = (
        UniqueConstraint("member_id", "league_id", name="uq_member_one_team_per_league"),
        UniqueConstraint("league_id", "team_name", name="uq_team_owned_once_per_league"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    member_id: Mapped[int] = mapped_column(ForeignKey("members.id"), nullable=False)
    league_id: Mapped[int] = mapped_column(ForeignKey("leagues.id"), nullable=False)
    team_name: Mapped[str] = mapped_column(String(150), nullable=False)
    # The Odds API identifies teams by name, not a stable numeric id -- keep the
    # exact string it returns so game matching stays reliable.
    odds_api_team_name: Mapped[str] = mapped_column(String(150), nullable=False)

    member: Mapped["Member"] = relationship(back_populates="owned_teams")
    league: Mapped["League"] = relationship(back_populates="owned_teams")
    game_lines: Mapped[list["GameLine"]] = relationship(
        back_populates="owned_team", cascade="all, delete-orphan"
    )
    game_results: Mapped[list["GameResult"]] = relationship(
        back_populates="owned_team", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<OwnedTeam id={self.id} team={self.team_name!r} member_id={self.member_id}>"


class GameLine(Base):
    """Pre-game spread, captured before kickoff so cover status is auditable later."""

    __tablename__ = "game_lines"
    __table_args__ = (
        UniqueConstraint("owned_team_id", "odds_api_event_id", name="uq_line_per_team_event"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    owned_team_id: Mapped[int] = mapped_column(ForeignKey("owned_teams.id"), nullable=False)
    odds_api_event_id: Mapped[str] = mapped_column(String(100), nullable=False)
    # Spread relative to the owned team, e.g. -3.5 means favored by 3.5.
    spread_for_team: Mapped[float] = mapped_column(Float, nullable=False)
    captured_at: Mapped[datetime] = mapped_column(nullable=False, default=datetime.utcnow)

    owned_team: Mapped["OwnedTeam"] = relationship(back_populates="game_lines")

    def __repr__(self) -> str:
        return f"<GameLine event={self.odds_api_event_id} spread={self.spread_for_team}>"


class GameResult(Base):
    """Final result for one game, with the per-game point value baked in at ingest."""

    __tablename__ = "game_results"
    __table_args__ = (
        UniqueConstraint("owned_team_id", "odds_api_event_id", name="uq_result_per_team_event"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    owned_team_id: Mapped[int] = mapped_column(ForeignKey("owned_teams.id"), nullable=False)
    odds_api_event_id: Mapped[str] = mapped_column(String(100), nullable=False)
    opponent_name: Mapped[str] = mapped_column(String(150), nullable=False)
    team_score: Mapped[int] = mapped_column(Integer, nullable=False)
    opponent_score: Mapped[int] = mapped_column(Integer, nullable=False)
    game_date: Mapped[datetime] = mapped_column(nullable=False)
    outcome: Mapped[Outcome] = mapped_column(Enum(Outcome), nullable=False)
    points: Mapped[int] = mapped_column(Integer, nullable=False)
    fetched_at: Mapped[datetime] = mapped_column(nullable=False, default=datetime.utcnow)

    owned_team: Mapped["OwnedTeam"] = relationship(back_populates="game_results")

    def __repr__(self) -> str:
        return (
            f"<GameResult team_id={self.owned_team_id} "
            f"{self.team_score}-{self.opponent_score} outcome={self.outcome} pts={self.points}>"
        )


class Schedule(Base):
    """
    One row per (round, pairing) for the whole season: 7 round-robin rounds,
    1 bye round, 2 playoff rounds (semifinal, final). Generated once per season.
    """

    __tablename__ = "schedule"
    __table_args__ = (
        UniqueConstraint("round_number", "member_a_id", "member_b_id", name="uq_schedule_pairing"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    # "2027-03" .. "2027-12" -- one calendar month per round, March through December.
    period: Mapped[str] = mapped_column(String(7), nullable=False)
    round_number: Mapped[int] = mapped_column(Integer, nullable=False)  # 1-10
    member_a_id: Mapped[int] = mapped_column(ForeignKey("members.id"), nullable=False)
    # Nullable: a bye round pairs a member against no one.
    member_b_id: Mapped[int | None] = mapped_column(ForeignKey("members.id"), nullable=True)
    is_bye: Mapped[bool] = mapped_column(default=False, nullable=False)
    is_playoff: Mapped[bool] = mapped_column(default=False, nullable=False)
    # e.g. "Semifinal", "Final" -- null for regular-season rounds.
    round_name: Mapped[str | None] = mapped_column(String(50), nullable=True)

    member_a: Mapped["Member"] = relationship(foreign_keys=[member_a_id])
    member_b: Mapped["Member | None"] = relationship(foreign_keys=[member_b_id])
    matchup: Mapped["Matchup | None"] = relationship(
        back_populates="schedule_entry", uselist=False, cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Schedule round={self.round_number} period={self.period} a={self.member_a_id} b={self.member_b_id}>"


class Matchup(Base):
    """
    Resolved result of one Schedule pairing: each member's summed GameResult
    points for that period, and the winner. Computed by the monthly
    aggregation job after a period closes (or on-demand for a live view).
    """

    __tablename__ = "matchups"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    schedule_id: Mapped[int] = mapped_column(
        ForeignKey("schedule.id"), unique=True, nullable=False
    )
    member_a_points: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    member_b_points: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    # Null until resolved, or always null for a bye round.
    winner_id: Mapped[int | None] = mapped_column(ForeignKey("members.id"), nullable=True)
    is_final: Mapped[bool] = mapped_column(default=False, nullable=False)

    schedule_entry: Mapped["Schedule"] = relationship(back_populates="matchup")
    winner: Mapped["Member | None"] = relationship(foreign_keys=[winner_id])

    def __repr__(self) -> str:
        return (
            f"<Matchup schedule_id={self.schedule_id} "
            f"{self.member_a_points}-{self.member_b_points} winner_id={self.winner_id}>"
        )
