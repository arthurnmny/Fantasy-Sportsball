"""
Silver -> Gold transformations.

Gold tables are fully rebuilt on each run (delete + reinsert), not
incrementally updated -- simplest correct approach at this data volume
(8 members, 56 teams, one season). Revisit if the season history grows
large enough that a full rebuild gets slow.
"""
from __future__ import annotations

from collections import defaultdict

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from gold_models import (
    GoldLeagueBreakdown,
    GoldMemberPeriodScore,
    GoldPlayoffBracket,
    GoldStandings,
    GoldTeamLeaderboard,
)
from models import Member, OwnedTeam
from silver_models import SilverGameFact, SilverMatchupFact


def build_gold_standings(session: Session) -> int:
    """
    One row per member: head-to-head record (wins/losses/ties in Matchups)
    plus season cumulative points (the tiebreaker for seeding).
    """
    session.execute(delete(GoldStandings))

    members = session.execute(select(Member)).scalars().all()
    facts = session.execute(select(SilverMatchupFact)).scalars().all()
    game_facts = session.execute(select(SilverGameFact)).scalars().all()

    record: dict[int, dict[str, int]] = {m.id: {"wins": 0, "losses": 0, "ties": 0} for m in members}
    for f in facts:
        if f.member_a_points > f.member_b_points:
            record[f.member_a_id]["wins"] += 1
            record[f.member_b_id]["losses"] += 1
        elif f.member_b_points > f.member_a_points:
            record[f.member_b_id]["wins"] += 1
            record[f.member_a_id]["losses"] += 1
        else:
            record[f.member_a_id]["ties"] += 1
            record[f.member_b_id]["ties"] += 1

    season_points: dict[int, int] = defaultdict(int)
    for g in game_facts:
        season_points[g.member_id] += g.points

    # Seed by record first (wins desc, losses asc), then season_points as tiebreaker.
    ranked = sorted(
        members,
        key=lambda m: (
            -record[m.id]["wins"],
            record[m.id]["losses"],
            -season_points[m.id],
        ),
    )

    rows_built = 0
    for seed, member in enumerate(ranked, start=1):
        session.add(
            GoldStandings(
                member_id=member.id,
                member_name=member.name,
                wins=record[member.id]["wins"],
                losses=record[member.id]["losses"],
                ties=record[member.id]["ties"],
                season_points=season_points[member.id],
                current_seed=seed,
            )
        )
        rows_built += 1

    session.commit()
    return rows_built


def build_gold_member_period_scores(session: Session) -> int:
    """One row per member per period -- feeds the score-over-time trend chart."""
    session.execute(delete(GoldMemberPeriodScore))

    game_facts = session.execute(select(SilverGameFact)).scalars().all()
    matchup_facts = session.execute(select(SilverMatchupFact)).scalars().all()

    points_by_member_period: dict[tuple[int, str], int] = defaultdict(int)
    for g in game_facts:
        points_by_member_period[(g.member_id, g.period)] += g.points

    result_lookup: dict[tuple[int, str], tuple[str, int | None]] = {}
    for f in matchup_facts:
        a_result = "win" if f.member_a_points > f.member_b_points else (
            "tie" if f.member_a_points == f.member_b_points else "loss"
        )
        b_result = "win" if f.member_b_points > f.member_a_points else (
            "tie" if f.member_a_points == f.member_b_points else "loss"
        )
        result_lookup[(f.member_a_id, f.period)] = (a_result, f.member_b_id)
        result_lookup[(f.member_b_id, f.period)] = (b_result, f.member_a_id)

    rows_built = 0
    for (member_id, period), points in points_by_member_period.items():
        matchup_result, opponent_id = result_lookup.get((member_id, period), (None, None))
        session.add(
            GoldMemberPeriodScore(
                member_id=member_id,
                period=period,
                points_scored=points,
                opponent_id=opponent_id,
                matchup_result=matchup_result,
            )
        )
        rows_built += 1

    session.commit()
    return rows_built


def build_gold_team_leaderboard(session: Session) -> int:
    """One row per owned team for the season."""
    session.execute(delete(GoldTeamLeaderboard))

    owned_teams = session.execute(select(OwnedTeam)).scalars().all()
    game_facts = session.execute(select(SilverGameFact)).scalars().all()

    by_team: dict[int, list[SilverGameFact]] = defaultdict(list)
    for g in game_facts:
        by_team[g.owned_team_id].append(g)

    rows_built = 0
    for team in owned_teams:
        team_games = by_team.get(team.id, [])
        wins = sum(1 for g in team_games if g.team_score > g.opponent_score)
        losses = sum(1 for g in team_games if g.team_score < g.opponent_score)
        ties = sum(1 for g in team_games if g.team_score == g.opponent_score)
        covers = sum(1 for g in team_games if g.outcome.value == "win_cover")
        games_played = len(team_games)
        cover_rate = covers / games_played if games_played else 0.0
        total_points = sum(g.points for g in team_games)

        session.add(
            GoldTeamLeaderboard(
                owned_team_id=team.id,
                member_id=team.member_id,
                member_name=team_games[0].member_name if team_games else "",
                league_id=team.league_id,
                league_name=team_games[0].league_name if team_games else "",
                team_name=team.team_name,
                games_played=games_played,
                wins=wins,
                losses=losses,
                ties=ties,
                covers=covers,
                cover_rate=round(cover_rate, 3),
                total_points=total_points,
            )
        )
        rows_built += 1

    session.commit()
    return rows_built


def build_gold_league_breakdown(session: Session) -> int:
    """One row per (member, league) -- which league is carrying each member's score."""
    session.execute(delete(GoldLeagueBreakdown))

    game_facts = session.execute(select(SilverGameFact)).scalars().all()

    grouped: dict[tuple[int, int], dict] = {}
    for g in game_facts:
        key = (g.member_id, g.league_id)
        if key not in grouped:
            grouped[key] = {
                "member_name": g.member_name,
                "league_name": g.league_name,
                "games_played": 0,
                "total_points": 0,
            }
        grouped[key]["games_played"] += 1
        grouped[key]["total_points"] += g.points

    rows_built = 0
    for (member_id, league_id), agg in grouped.items():
        session.add(
            GoldLeagueBreakdown(
                member_id=member_id,
                member_name=agg["member_name"],
                league_id=league_id,
                league_name=agg["league_name"],
                games_played=agg["games_played"],
                total_points=agg["total_points"],
            )
        )
        rows_built += 1

    session.commit()
    return rows_built


def build_gold_playoff_bracket(session: Session) -> int:
    """
    Build/update the playoff bracket from playoff SilverMatchupFacts, with
    seeds pulled from the already-built GoldStandings.
    """
    session.execute(delete(GoldPlayoffBracket))

    seeds: dict[int, int] = {
        s.member_id: s.current_seed
        for s in session.execute(select(GoldStandings)).scalars().all()
    }
    playoff_facts = session.execute(
        select(SilverMatchupFact).where(SilverMatchupFact.is_playoff.is_(True))
    ).scalars().all()

    rows_built = 0
    for f in playoff_facts:
        session.add(
            GoldPlayoffBracket(
                round_name=f.round_name or f"Round {f.round_number}",
                member_a_id=f.member_a_id,
                member_a_name=f.member_a_name,
                member_a_seed=seeds.get(f.member_a_id),
                member_b_id=f.member_b_id,
                member_b_name=f.member_b_name,
                member_b_seed=seeds.get(f.member_b_id),
                member_a_points=f.member_a_points,
                member_b_points=f.member_b_points,
                winner_id=f.winner_id,
                is_final=True,
            )
        )
        rows_built += 1

    session.commit()
    return rows_built


def build_all_gold(session: Session) -> dict[str, int]:
    """Run all silver -> gold builds in dependency order (standings before bracket) and return row counts."""
    return {
        "gold_standings": build_gold_standings(session),
        "gold_member_period_scores": build_gold_member_period_scores(session),
        "gold_team_leaderboard": build_gold_team_leaderboard(session),
        "gold_league_breakdown": build_gold_league_breakdown(session),
        "gold_playoff_bracket": build_gold_playoff_bracket(session),
    }
