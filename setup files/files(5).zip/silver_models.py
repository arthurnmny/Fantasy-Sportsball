"""
Silver layer: bronze data cleaned, deduplicated, and joined to a consistent
grain. Still one row per real-world event (a game, a matchup) -- not yet
rolled up into dashboard aggregates. That's the gold layer's job.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, Float, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from models import Base, Outcome


class SilverGameFact(Base):
    """
    One row per (owned team, game) -- GameResult + GameLine + OwnedTeam +
    Member + League flattened into a single row, so the dashboard never has
    to join four bronze tables to answer "how did Bob's Lakers do in April."
    """

    __tablename__ = "silver_game_facts"
    __table_args__ = (
        UniqueConstraint("source_result_id", name="uq_silver_game_fact_source"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)

    # Lineage back to bronze -- always keep a path to the raw source.
    source_result_id: Mapped[int] = mapped_column(ForeignKey("game_results.id"), nullable=False)
    source_line_id: Mapped[int | None] = mapped_column(ForeignKey("game_lines.id"), nullable=True)

    owned_team_id: Mapped[int] = mapped_column(ForeignKey("owned_teams.id"), nullable=False)
    member_id: Mapped[int] = mapped_column(ForeignKey("members.id"), nullable=False)
    member_name: Mapped[str] = mapped_column(String(100), nullable=False)
    league_id: Mapped[int] = mapped_column(ForeignKey("leagues.id"), nullable=False)
    league_name: Mapped[str] = mapped_column(String(50), nullable=False)
    team_name: Mapped[str] = mapped_column(String(150), nullable=False)
    opponent_name: Mapped[str] = mapped_column(String(150), nullable=False)

    game_date: Mapped[datetime] = mapped_column(nullable=False)
    # "2027-03" .. "2027-12" -- derived from game_date, used to bucket into matchup periods.
    period: Mapped[str] = mapped_column(String(7), nullable=False)

    spread_for_team: Mapped[float | None] = mapped_column(Float, nullable=True)
    team_score: Mapped[int] = mapped_column(Integer, nullable=False)
    opponent_score: Mapped[int] = mapped_column(Integer, nullable=False)
    outcome: Mapped[Outcome] = mapped_column(nullable=False)
    points: Mapped[int] = mapped_column(Integer, nullable=False)

    # Data-quality flag: false if outcome/points were re-derived from the raw
    # score and didn't match what bronze had stored (a scoring-logic bug, or
    # a line that arrived after the game started).
    is_valid: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    built_at: Mapped[datetime] = mapped_column(nullable=False, default=datetime.utcnow)

    def __repr__(self) -> str:
        return f"<SilverGameFact {self.member_name}/{self.team_name} {self.period} pts={self.points}>"


class SilverMatchupFact(Base):
    """One row per resolved Schedule pairing, with both members' names and margin added."""

    __tablename__ = "silver_matchup_facts"
    __table_args__ = (
        UniqueConstraint("source_matchup_id", name="uq_silver_matchup_source"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source_matchup_id: Mapped[int] = mapped_column(ForeignKey("matchups.id"), nullable=False)
    schedule_id: Mapped[int] = mapped_column(ForeignKey("schedule.id"), nullable=False)

    period: Mapped[str] = mapped_column(String(7), nullable=False)
    round_number: Mapped[int] = mapped_column(Integer, nullable=False)
    is_playoff: Mapped[bool] = mapped_column(Boolean, nullable=False)
    round_name: Mapped[str | None] = mapped_column(String(50), nullable=True)

    member_a_id: Mapped[int] = mapped_column(ForeignKey("members.id"), nullable=False)
    member_a_name: Mapped[str] = mapped_column(String(100), nullable=False)
    member_a_points: Mapped[int] = mapped_column(Integer, nullable=False)

    member_b_id: Mapped[int] = mapped_column(ForeignKey("members.id"), nullable=False)
    member_b_name: Mapped[str] = mapped_column(String(100), nullable=False)
    member_b_points: Mapped[int] = mapped_column(Integer, nullable=False)

    winner_id: Mapped[int | None] = mapped_column(ForeignKey("members.id"), nullable=True)
    winner_name: Mapped[str | None] = mapped_column(String(100), nullable=True)
    margin: Mapped[int] = mapped_column(Integer, nullable=False)  # abs(a_points - b_points)

    built_at: Mapped[datetime] = mapped_column(nullable=False, default=datetime.utcnow)

    def __repr__(self) -> str:
        return f"<SilverMatchupFact {self.member_a_name} vs {self.member_b_name} {self.period}>"


class SilverScheduleResolved(Base):
    """
    Schedule with playoff pairings filled in. Bronze Schedule rows for playoff
    rounds start with member_a_id/member_b_id as placeholders (nullable) until
    the regular season ends -- this table only ever holds fully-resolved rows.
    """

    __tablename__ = "silver_schedule_resolved"
    __table_args__ = (
        UniqueConstraint("source_schedule_id", name="uq_silver_schedule_source"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source_schedule_id: Mapped[int] = mapped_column(ForeignKey("schedule.id"), nullable=False)

    period: Mapped[str] = mapped_column(String(7), nullable=False)
    round_number: Mapped[int] = mapped_column(Integer, nullable=False)
    member_a_id: Mapped[int] = mapped_column(ForeignKey("members.id"), nullable=False)
    member_b_id: Mapped[int] = mapped_column(ForeignKey("members.id"), nullable=False)
    is_playoff: Mapped[bool] = mapped_column(Boolean, nullable=False)
    round_name: Mapped[str | None] = mapped_column(String(50), nullable=True)

    resolved_at: Mapped[datetime] = mapped_column(nullable=False, default=datetime.utcnow)

    def __repr__(self) -> str:
        return f"<SilverScheduleResolved round={self.round_number} a={self.member_a_id} b={self.member_b_id}>"
